$("#Survey_btn").click(function (e) {
  let title = $(this).attr("id");
  let windowElem = $(this).data("window");
  let FBhtml = "";
  FBhtml =
    '<div id="feedback" class = "feedback-container" style="display:none"><strong>How satisfied are you with my website? Please click the emojis below!</strong>' +
    ' <div class="ratings-container"><div class="rating active" id="ch1"><img src="images/emoji_happy.png" alt=""><br/><small>Happy</small></div>' +
    '<div class="rating" id="ch2"><img src="images/emoji_Neutral.png" alt=""/><br/><small>Neutral</small></div>' +
    ' <div class="rating" id="ch3"><img src="images/emoji_Not_Satisfy.png" alt=""/><br/><small>Not satisfied</small></div>' +
    "</div>" +
    '<div><textarea id="reviewcomment" name="review" rows="4" cols="40"></textarea></div>' +
    "<br></br>" +
    '<button class="FBBtnPrimButton btn" id="send">Send Review</button>' +
    "</div>";
  $(".navbar").after(FBhtml);
  $("#feedback").dialog({
    width: 400,
    title: "Feedback",
    modal: true,
    close: function (ev, ui) {
      $("#feedback").remove();
    },
  });
  const ratingsContainer = document.querySelector(".ratings-container");
  const sendBtn = document.querySelector("#send");
  let selectedRating = "Satisfied";
  const comment = document.querySelector("#reviewcomment");
  ratingsContainer.addEventListener("click", (e) => {
    if (
      e.target.parentNode.classList.contains("rating") &&
      e.target.nextElementSibling
    ) {
      removeActive();
      e.target.parentNode.classList.add("active");
      selectedRating = e.target.nextElementSibling.nextElementSibling.innerHTML;
      comment.innerHTML = selectedRating + " !!";
    } else if (
      e.target.parentNode.classList.contains("rating") &&
      e.target.previousSibling &&
      e.target.previousElementSibling.nodeName === "IMG"
    ) {
      removeActive();
      e.target.parentNode.classList.add("active");
    }
  });
  sendBtn.addEventListener("click", (e) => {
    userCmnt = comment.value;

    feedback.innerHTML = `<i class="fas fa-heart"></i><strong>Thank You!</strong><br><strong>Feedback:${selectedRating}</strong><p>We will use your feedback to improve our website features</p>`;
  });
});

function removeActive() {
  var ratings1 = document.querySelectorAll(".rating");
  for (let i = 0; i < ratings1.length; i++) {
    ratings1[i].classList.remove("active");
  }
}

$("#hlp_btn1").click(function (e) {
  window.open("https://youthline.co.nz/");
});

$("#hlp_btn2").click(function (e) {
  window.open("https://mentalhealth.org.nz/helplines");
});

$("#hlp_btn3").click(function (e) {
  window.open("https://www.depression.org.nz/get-help");
});

//rishita's work  